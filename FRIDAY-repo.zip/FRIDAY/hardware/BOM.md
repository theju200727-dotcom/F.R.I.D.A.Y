# Bill of Materials

| Item | Qty | Notes |
|---|---|---|
| ESP32 DevKit V1 (30-pin) | 3 | Base A, Drone, Base C |
| Waveshare Core1262 (SX1262) LoRa module, 868 MHz | 4 | 1 each for Base A/C, 2 for the drone |
| LPDA directional antenna | 1 | Uplink leg (Base A ↔ Drone), best gain-to-size tradeoff for the directional link |
| IPEX omnidirectional antenna | 2+ | Downlink leg (Drone ↔ Base C) and spares |
| N-to-SMA adapter + SMA-to-U.FL pigtail | 1 set | LPDA → Core1262 U.FL socket, no soldering required |
| AMS1117 3.3V regulator module | 1 | Drone board — mandatory for dual-radio power stability |
| SW-420 vibration sensor module | 1 | Base A — hardware disaster-trigger demo |
| Power banks (5V USB) | 2–3 | Base A / Base C field power |
| Jumper wires, breadboard or perfboard | — | Assembly |

## Notes

- Do not power two SX1262 radios from the ESP32's onboard 3.3V rail alone — use the external AMS1117 on the drone board.
- The LPDA's rated gain (often listed near 12 dBi) is a peak figure at higher frequencies; expect realistic gain around 5–7 dBi at 868 MHz when sizing your link budget.
